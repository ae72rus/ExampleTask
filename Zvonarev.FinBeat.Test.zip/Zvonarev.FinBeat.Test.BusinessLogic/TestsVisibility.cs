﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Zvonarev.FinBeat.Test.BusinessLogic.Tests")]