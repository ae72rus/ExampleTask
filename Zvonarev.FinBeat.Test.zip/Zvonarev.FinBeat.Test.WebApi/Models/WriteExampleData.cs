﻿using Swashbuckle.AspNetCore.Filters;

namespace Zvonarev.FinBeat.Test.WebApi.Models;

public record WriteExampleData : IExamplesProvider<Dictionary<int, string>[]>
{
    public Dictionary<int, string>[] GetExamples()
        =>
        [
            new Dictionary<int, string>
            {
                {1, "value1"}
            },
            new Dictionary<int, string>
            {
                {5, "value2"}
            },
            new Dictionary<int, string>
            {
                {10, "value32"}
            }
        ];
}