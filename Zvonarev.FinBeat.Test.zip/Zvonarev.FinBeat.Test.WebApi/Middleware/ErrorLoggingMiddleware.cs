﻿namespace Zvonarev.FinBeat.Test.WebApi.Middleware;

internal class ErrorLoggingMiddleware
{
    private readonly ILogger<ErrorLoggingMiddleware> _logger;
    private readonly RequestDelegate _next;

    public ErrorLoggingMiddleware(ILogger<ErrorLoggingMiddleware> logger, RequestDelegate next)
    {
        _logger = logger;
        _next = next;
    }

    public async Task Invoke(HttpContext httpContext)
    {
        try
        {
            await _next(httpContext);
        }
        catch (Exception e)
        {
            _logger.LogCritical(e, "Request handling failed");
            throw;
        }
    }
}