﻿namespace Zvonarev.FinBeat.Test.Storage.Configuration;

public record StorageConfiguration
{
    public string ConnectionString { get; init; }
}