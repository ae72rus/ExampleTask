﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef.Models;

namespace Zvonarev.FinBeat.Test.Storage.UseCases.SaveDataEntries;

internal class SaveDataEntriesCommandHandler : IRequestHandler<SaveDataEntriesCommand>
{
    private readonly IDbContextFactory<AppDbContext> _dbContextFactory;
    private readonly ILogger<SaveDataEntriesCommandHandler> _logger;

    public SaveDataEntriesCommandHandler(IDbContextFactory<AppDbContext> dbContextFactory,
        ILogger<SaveDataEntriesCommandHandler> logger)
    {
        _dbContextFactory = dbContextFactory;
        _logger = logger;
    }

    public async Task Handle(SaveDataEntriesCommand request, CancellationToken cancellationToken)
    {
        try
        {
            var orderId = 0;
            var dbEntries = request
                    .Entries
                    .Select(x => new DbDataEntry(0, orderId++, x.Code, x.Value))
                ;

            await using var db = await _dbContextFactory.CreateDbContextAsync(cancellationToken);
            await db.Set<DbDataEntry>()
                .AddRangeAsync(dbEntries, cancellationToken);

            await db.SaveChangesAsync(cancellationToken);
        }
        catch
        {
            _logger.LogError("Failed to save data entries");
            throw;
        }
    }
}