﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef;

namespace Zvonarev.FinBeat.Test.Storage.UseCases.ApplyMigrations;

public record UpdateDbCommand:IRequest;

internal class UpdateDbCommandHandler : IRequestHandler<UpdateDbCommand>
{
    private readonly IDbContextFactory<AppDbContext> _appDbContextFactory;
    private readonly IDbContextFactory<LoggingDbContext> _loggingDbContextFactory;

    public UpdateDbCommandHandler(IDbContextFactory<AppDbContext> appDbContextFactory, IDbContextFactory<LoggingDbContext> loggingDbContextFactory)
    {
        _appDbContextFactory = appDbContextFactory;
        _loggingDbContextFactory = loggingDbContextFactory;
    }

    public async Task Handle(UpdateDbCommand request, CancellationToken cancellationToken)
    {
        await using var appDb = await _appDbContextFactory.CreateDbContextAsync(cancellationToken);
        await appDb.Database.MigrateAsync(cancellationToken);
        await using var loggingDb = await _loggingDbContextFactory.CreateDbContextAsync(cancellationToken);
        await loggingDb.Database.MigrateAsync(cancellationToken);
    }
}