﻿using MediatR;

namespace Zvonarev.FinBeat.Test.Storage.UseCases.ClearDataEntriesTable;

public record ClearDataEntriesCommand : IRequest;