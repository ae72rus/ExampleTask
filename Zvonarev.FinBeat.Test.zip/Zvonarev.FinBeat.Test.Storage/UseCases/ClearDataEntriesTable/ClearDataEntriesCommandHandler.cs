﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef.EntityConfigurations;

namespace Zvonarev.FinBeat.Test.Storage.UseCases.ClearDataEntriesTable;

internal class ClearDataEntriesCommandHandler : IRequestHandler<ClearDataEntriesCommand>
{
    private readonly IDbContextFactory<AppDbContext> _dbContextFactory;
    private readonly ILogger<ClearDataEntriesCommandHandler> _logger;

    public ClearDataEntriesCommandHandler(IDbContextFactory<AppDbContext> dbContextFactory,
        ILogger<ClearDataEntriesCommandHandler> logger)
    {
        _dbContextFactory = dbContextFactory;
        _logger = logger;
    }

    public async Task Handle(ClearDataEntriesCommand request, CancellationToken cancellationToken)
    {
        try
        {
            await using var db = await _dbContextFactory.CreateDbContextAsync(cancellationToken);
            await db.Database.ExecuteSqlRawAsync(
                $"TRUNCATE TABLE [{DbDataEntryConfiguration.Schema}].[{DbDataEntryConfiguration.TableName}]",
                cancellationToken);
        }
        catch
        {
            _logger.LogError("Failed to truncate data entries table");
            throw;
        }
    }
}