﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Zvonarev.FinBeat.Test.Storage.Tools.Ef;

namespace Zvonarev.FinBeat.Test.Storage.Tools.AppTransactioMiddleware;

internal class AppTransactionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IDbContextFactory<AppDbContext> _dbContextFactory;
    private readonly ILogger<AppTransactionMiddleware> _logger;

    public AppTransactionMiddleware(RequestDelegate next,
        IDbContextFactory<AppDbContext> dbContextFactory,
        ILogger<AppTransactionMiddleware> logger)
    {
        _next = next;
        _dbContextFactory = dbContextFactory;
        _logger = logger;
    }

    public async Task Invoke(HttpContext httpContext)
    {
        await using var db = await _dbContextFactory.CreateDbContextAsync();
        await using var transaction = await db.Database.BeginTransactionAsync();
        try
        {
            await _next.Invoke(httpContext);
        }
        finally
        {
            try
            {
                await transaction.CommitAsync();
            }
            catch (Exception e)
            {
                _logger.LogCritical(e, "Failed to commit request transaction");
                throw;
            }
        }
    }
}