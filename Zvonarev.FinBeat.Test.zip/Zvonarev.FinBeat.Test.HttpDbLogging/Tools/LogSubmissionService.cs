﻿using MediatR;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Zvonarev.FinBeat.Test.HttpDbLogging.Configuration;
using Zvonarev.FinBeat.Test.Storage.UseCases.SaveApiLog;

namespace Zvonarev.FinBeat.Test.HttpDbLogging.Tools;

internal class LogSubmissionService : IHostedService
{
    private Task _submissionJob;
    private bool _stopRequested;
    private readonly IMediator _mediator;
    private readonly LogsContainer _logsContainer;
    private readonly HttpLoggingConfiguration _loggingConfiguration;
    private readonly ILogger<LogSubmissionService> _logger;

    public LogSubmissionService(IMediator mediator,
        LogsContainer logsContainer,
        HttpLoggingConfiguration loggingConfiguration,
        ILogger<LogSubmissionService> logger)
    {
        _mediator = mediator;
        _logsContainer = logsContainer;
        _loggingConfiguration = loggingConfiguration;
        _logger = logger;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _submissionJob = RunLogsSubmission();

        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        _stopRequested = true;
        await _submissionJob;
    }

    private async Task RunLogsSubmission()
    {
        while (true)
        {
            var logsBatch = _logsContainer
                .GetLogsBatch()
                .ToArray();

            if (!logsBatch.Any() && _stopRequested)
                break;

            try
            {
                if (logsBatch.Any())
                    await _mediator.Send(new SaveApiLogsCommand(logsBatch));
            }
            catch (Exception e)
            {
                _logger.LogCritical(e, "Failed to save api requests logs");
            }

            await Task.Delay(_loggingConfiguration.DefaultLogSubmissionInterval);
        }
    }
}