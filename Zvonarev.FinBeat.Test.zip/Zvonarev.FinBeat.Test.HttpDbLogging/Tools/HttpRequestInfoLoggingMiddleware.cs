﻿using System.Diagnostics;
using System.Text;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Zvonarev.FinBeat.Test.DomainObjects;
using Zvonarev.FinBeat.Test.HttpDbLogging.UseCases.LogHttpInfo;

namespace Zvonarev.FinBeat.Test.HttpDbLogging.Tools;

internal class HttpRequestInfoLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IMediator _mediator;
    private readonly ILogger<HttpRequestInfoLoggingMiddleware> _logger;

    //todo make config setting
    private const int _maxSize = 4096 * 4;//16KB

    private bool _isErrorOccurred;

    public HttpRequestInfoLoggingMiddleware(RequestDelegate next,
        IMediator mediator,
        ILogger<HttpRequestInfoLoggingMiddleware> logger)
    {
        _next = next;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task Invoke(HttpContext httpContext)
    {
        var requestId = Guid.NewGuid().ToString();
        var sw = new Stopwatch();
        var originalResponseStream = httpContext.Response.Body;
        var originalRequestStream = httpContext.Request.Body;
        await using var mockResponseStream = new MemoryStream();
        await using var mockRequestStream = new MemoryStream();

        var requestLength = httpContext.Request.ContentLength ?? 0L;
        if (requestLength > 0)
            await originalRequestStream.CopyToAsync(mockRequestStream, (int)requestLength);

        mockRequestStream.Seek(0, SeekOrigin.Begin);

        httpContext.Response.Body = mockResponseStream;
        httpContext.Request.Body = mockRequestStream;
        try
        {
            using var loggerScope = _logger.BeginScope(new
            {
                RequestId = requestId,
                HttpRequestId = httpContext.TraceIdentifier
            });
            sw.Start();
            await _next(httpContext);
        }
        catch
        {
            _isErrorOccurred = true;
            throw;
        }
        finally
        {
            sw.Stop();
            await SaveRequestInfo(httpContext, requestId, sw.Elapsed);
            mockResponseStream.Seek(0, SeekOrigin.Begin);
            await mockResponseStream.CopyToAsync(originalResponseStream);
        }
    }

    private async Task SaveRequestInfo(HttpContext context, string requestId, TimeSpan requestProcessingTime)
    {
        try
        {
            var info = await GetRequestInfo(context, requestId, requestProcessingTime);
            await _mediator.Send(new AddHttpInfoCommand(info));
        }
        catch (Exception e)
        {
            _logger.LogCritical(e, "Failed to save http request info");
        }
    }

    private async Task<HttpRequestInfo> GetRequestInfo(HttpContext context, string requestId, TimeSpan requestProcessingTime)
    {
        var headersLineBuilder = new StringBuilder();
        foreach (var header in context.Request.Headers)
            foreach (var value in header.Value)
                headersLineBuilder.Append($"{header.Key}: {value}{Environment.NewLine}");

        var info = new HttpRequestInfo(
            requestId,
            context.TraceIdentifier,
            context.Connection.RemoteIpAddress?.ToString() ?? "<unknown>",
            context.Request.Method,
            $"{context.Request.Path}{context.Request.QueryString.ToUriComponent()}",
            headersLineBuilder.ToString(),
            await GetRequestBody(context),
            _isErrorOccurred ? 500 : context.Response.StatusCode,
            await GetResponsePayload(context),
            requestProcessingTime
        );

        return info;
    }

    private async Task<string?> GetRequestBody(HttpContext context)
    {
        var requestStream = (MemoryStream)context.Request.Body;
        if (context.Request.ContentLength == 0)
            return null;

        return await ReadFromStream(requestStream);
    }

    private async Task<string?> GetResponsePayload(HttpContext context)
    {
        var responseStream = (MemoryStream)context.Response.Body;

        if (responseStream.Length == 0)
            return null;

        return await ReadFromStream(responseStream);
    }

    private async Task<string?> ReadFromStream(MemoryStream stream)
    {
        await stream.FlushAsync();
        stream.Seek(0, SeekOrigin.Begin);

        var bytes = stream.ToArray();

        var sb = new StringBuilder(Encoding.UTF8.GetString(bytes, 0, bytes.Length > _maxSize ? _maxSize : bytes.Length));

        if (stream.Length > _maxSize)
            sb.Append("...<content is too long>");

        return sb.ToString();
    }
}