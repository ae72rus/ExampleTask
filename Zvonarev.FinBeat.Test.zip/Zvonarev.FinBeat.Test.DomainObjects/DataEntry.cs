﻿namespace Zvonarev.FinBeat.Test.DomainObjects;

public record DataEntry(int Code, string Value);